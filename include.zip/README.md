# Simple Shadow FireWall

It used [Pcap](https://github.com/the-tcpdump-group/libpcap) library for receiving packet from kernel.

You can try it:

```bash
mkdir build
cd build
cmake ..
make 
sudo ./Shadow
```